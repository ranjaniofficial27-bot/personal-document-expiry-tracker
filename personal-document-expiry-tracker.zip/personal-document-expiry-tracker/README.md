# Personal Document Expiry Tracker

A responsive full-stack app for tracking document expiry dates.

## Features
- Add, edit, delete, search, and filter documents
- Automatically classify documents as Active, Expiring Soon (within 30 days), or Expired
- Dashboard summary cards and an expiry watch list
- Express REST API
- JSON-file storage by default; optional MySQL schema included

## Requirements
- Node.js 18+ and npm

## Run locally
Open a terminal in the project folder and run:

```bash
npm install
npm run install:all
npm run dev
```

Open the Vite URL shown in the terminal (usually http://localhost:5173).

The server runs on http://localhost:4000. JSON data is stored in `server/data/store.json`.

## Optional MySQL
A starter schema is in `server/schema.sql`. MySQL integration is not enabled by default; the app uses JSON storage unless you add your own database adapter.

## Notes
- The file-upload area is currently a UI placeholder, not a working upload.
- Expiry reminders appear in the dashboard; email/push notifications are not implemented.
- Do not commit passwords, API keys, or real `.env` files to GitHub.
