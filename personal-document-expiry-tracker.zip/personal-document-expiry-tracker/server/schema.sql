CREATE DATABASE IF NOT EXISTS document_tracker;
USE document_tracker;

CREATE TABLE IF NOT EXISTS documents (
  id CHAR(36) PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  category VARCHAR(60) NOT NULL DEFAULT 'Other',
  document_number VARCHAR(120),
  issue_date DATE,
  expiry_date DATE NOT NULL,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_expiry_date (expiry_date)
);
