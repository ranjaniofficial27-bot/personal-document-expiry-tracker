import express from 'express';
import cors from 'cors';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 4000;
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'store.json');
app.use(cors());
app.use(express.json({ limit: '1mb' }));

async function readDocs() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  try { return JSON.parse(await fs.readFile(DATA_FILE, 'utf8')); }
  catch { await fs.writeFile(DATA_FILE, '[]', 'utf8'); return []; }
}
async function writeDocs(docs) {
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.writeFile(DATA_FILE, JSON.stringify(docs, null, 2), 'utf8');
}
app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));
app.get('/api/documents', async (_req, res, next) => {
  try { res.json(await readDocs()); } catch (e) { next(e); }
});
app.post('/api/documents', async (req, res, next) => {
  try {
    const { name, expiryDate } = req.body;
    if (!String(name || '').trim() || !expiryDate) return res.status(400).json({ error: 'Name and expiry date are required.' });
    const docs = await readDocs();
    const doc = { id: crypto.randomUUID(), name: String(name).trim(), category: req.body.category || 'Other', number: req.body.number || '', issueDate: req.body.issueDate || '', expiryDate, notes: req.body.notes || '' };
    docs.unshift(doc); await writeDocs(docs); res.status(201).json(doc);
  } catch (e) { next(e); }
});
app.put('/api/documents/:id', async (req, res, next) => {
  try {
    const docs = await readDocs(); const i = docs.findIndex(d => d.id === req.params.id);
    if (i < 0) return res.status(404).json({ error: 'Document not found.' });
    docs[i] = { ...docs[i], ...req.body, id: docs[i].id };
    await writeDocs(docs); res.json(docs[i]);
  } catch (e) { next(e); }
});
app.delete('/api/documents/:id', async (req, res, next) => {
  try {
    const docs = await readDocs(); const remaining = docs.filter(d => d.id !== req.params.id);
    if (remaining.length === docs.length) return res.status(404).json({ error: 'Document not found.' });
    await writeDocs(remaining); res.status(204).end();
  } catch (e) { next(e); }
});
app.use((err, _req, res, _next) => {
  console.error(err); res.status(500).json({ error: 'Something went wrong.' });
});
app.listen(PORT, () => console.log(`Document tracker API running at http://localhost:${PORT}`));
